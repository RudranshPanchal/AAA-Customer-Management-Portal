package com.lithan.aaa.constants;

/**
 * @author DELL
 */
public class AAACustomerProtletPortletKeys {

	public static final String AAACUSTOMERPROTLET =
		"com_lithan_aaa_AAACustomerProtletPortlet";

}